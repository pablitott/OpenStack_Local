rabbitMQ
=========

This role installs RabbitMQ and creates a user with full privileges

Requirements
------------

None

Role Variables
--------------

The following variable needs to be set when calling this role.

* rabbitmq_user_name - name of the user that we create
* rabbit_user_password - password of that user

Dependencies
------------

None


License
-------

MIT

Author Information
------------------

Visit me at https://www.github.com/christianb93
