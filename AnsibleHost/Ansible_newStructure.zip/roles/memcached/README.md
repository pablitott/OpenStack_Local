memcached
=========

This role installs memcached

Requirements
------------

None

Role Variables
--------------

The following variable has a default, but can be overwritten if needed.

* memcached_server_ip: the IP address on which the server will listen 

Dependencies
------------

None


License
-------

MIT

Author Information
------------------

Visit me at https://www.github.com/christianb93
