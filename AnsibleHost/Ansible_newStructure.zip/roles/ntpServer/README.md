ntpServer
=========

Install an NTP server

Requirements
------------

None

Role Variables
--------------

* ntp_network_cidr: the network on which the server will be listening

Dependencies
------------

None

License
-------

MIT

Author Information
------------------

Visit me on https://www.github.com/christianb93
