firewall
=========

Install the latest version of the UFW firewall on a machine and set up basic rules. OpenSSH incoming traffic will be allowed, all other incoming traffic will be denied

Requirements
------------

None

Role Variables
--------------

None 

Dependencies
------------

None

License
-------

MIT

Author Information
------------------

Visit me on https://www.github.com/christianb93
