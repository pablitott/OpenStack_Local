ntpClient
=========

Install an NTP client

Requirements
------------

None

Role Variables
--------------

The following variable needs to be set when calling this role.

* ntp_node: the name of the NTP server - needs to be a name which can be resolved.

Dependencies
------------

None

License
-------

MIT

Author Information
------------------

Visit me on https://www.github.com/christianb93
